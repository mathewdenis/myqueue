package myqueueserver.Log;

/**
 *
 * @author Nikos Siatras
 */
public enum LogMessageType
{

    Warning, Error, Information
}
