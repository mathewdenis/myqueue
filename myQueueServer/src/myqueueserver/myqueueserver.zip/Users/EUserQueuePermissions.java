package myqueueserver.Users;

import java.io.Serializable;

/**
 *
 * @author Nikos Siatras
 */
public enum EUserQueuePermissions implements Serializable
{

    Read, Write
}
